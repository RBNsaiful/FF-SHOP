import React from 'react';
export default function AuthScreen(){return <div>Auth Screen Placeholder</div>}
